# main.py
from journal_app import JournalApp

if __name__ == "__main__":
    app = JournalApp()
    app.mainloop()
